import spacy

nlp = spacy.load("./models/models-best")

f = open("plneb-2526\TPC6\Harry Potter e A Pedra Filosofal.txt")
texto = f.read()

doc = nlp(texto)

for ent in doc.ents:
    print(ent, ent.label_)